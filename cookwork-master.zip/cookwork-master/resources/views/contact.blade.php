@extends('layout.master')

@section('pages')

<div class="container">
    <div class="mt-5">
          <h1>HELLO WORLD!</h1>
    </div>
</div>

@endsection