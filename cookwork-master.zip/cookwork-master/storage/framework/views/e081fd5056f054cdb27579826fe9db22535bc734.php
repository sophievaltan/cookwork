<?php $__env->startSection('pages'); ?>

<div class="container">
    <div class="mt-5">
          <h1>HELLO WORLD!</h1>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sevenacademy/Documents/cookwork/resources/views/menu.blade.php ENDPATH**/ ?>